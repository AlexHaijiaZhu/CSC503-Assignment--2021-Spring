k_means_init.m contains different initalization method.
mykmeans.m is the main function of k-means implementation.
result.mlx contains all the experiement result and code
To load the daataset1 and 2, include the foler into matlab path folder, and run the first section in result.mlx.
