Folder:

- data: contians all the trained models
- init:  the training and testing datasets
- utilities: all the function
  - All the code( except the code in *libsvm* )is writhing by myself.

Files:

- CSC 503 Part:
  - LR_SGD.m: Logistic regression using SGD
  - LR_SGD_Kfold.m: Tuning the schedule parameters using k-fold
  - LR_SGD_Kfold_find_C.m: Using the founded schedule parameters, searching the optimal C using k-fold CV
- Undergrade part:
  - Part_1&2.mlx: Logastic regression and SVM(linear kernel)
  - Part_3&4.mlx: Implemntation of k-fold, testing on SVM and logasitc regression,SVM(rbf kernekl)
  - confidence_interval.mlx: calation the test error and confidence intervel 



Note: Code is tested under win10, matlab 2020b. 

The toolbox used in this assignemnt:

- SVM: libsvm
- Logastic regression: Matlab machine leanrning and statics toolbox







